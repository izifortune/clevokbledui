# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# This file is in the public domain
### END LICENSE

from gi.repository import Gtk # pylint: disable=E0611

from clevokbledui_lib.helpers import get_builder

import gettext
from gettext import gettext as _
gettext.textdomain('clevokbledui')

class ErrorDialog(Gtk.MessageDialog):
    __gtype_name__ = "ErrorDialog"

    def __new__(cls):
        """Special static method that's automatically called by Python when 
        constructing a new instance of this class.
        
        Returns a fully instantiated ErrorDialog object.
        """
        return Gtk.MessageDialog(None,0,Gtk.MessageType.ERROR,
                Gtk.ButtonsType.OK, 'Error')
if __name__ == "__main__":
    dialog = ErrorDialog()
    dialog.show()
    Gtk.main()
