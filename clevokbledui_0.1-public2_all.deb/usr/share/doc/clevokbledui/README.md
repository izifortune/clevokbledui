clevokbledui
============

Gtk UI for using clevo laptop backlit keyboard ( using clevo-wmi )

Install this driver http://sourceforge.net/projects/clevo-wmi/ 
than you can use the clevokbledui

There's also a ppa for ubuntu users:

https://launchpad.net/~fortune-c/+archive/ppa-fortune
